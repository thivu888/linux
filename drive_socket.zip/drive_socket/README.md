1, Trước tiên chúng ta cần cài drive 
-> vào thư mục encrypt_module
    -> chạy lệnh make install 
        -> sau khi chạy xong cd ..
2 , mở 1 terminal chạy ./server
    -> để chạy server
3, chạy các terminal còn lại để chạy sudo ./client
    -> chạy các client để chat với nhau
4, sau khi chạy client  thì nhập tên chat rồi chat với nhau
